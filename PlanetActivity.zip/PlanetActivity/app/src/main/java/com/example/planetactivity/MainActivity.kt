package com.example.planetactivity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.planetactivity.ui.theme.PlanetActivityTheme

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PlanetActivityTheme {
                Scaffold(
                    topBar = {
                        TopAppBar(title = { Text("Planet Quiz") })
                    },
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    QuizScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun QuizScreen(modifier: Modifier = Modifier) {
    var currentQuestion by remember { mutableIntStateOf(0) }
    var selectedAnswer by remember { mutableStateOf<String?>(null) }
    var showResult by remember { mutableStateOf(false) }

    val questions = listOf(
        "What is the largest planet?",
        "Which planet has the most moons?",
        "Which planet spins on its side?"
    )

    val explanations = listOf(
        "Jupiter is the largest planet and is 2.5 times the mass of all the other planets put together.",
        "Saturn has the most moons and has 82 moons.",
        "Uranus spins on its side with its axis at nearly a right angle to the Sun."
    )

    val correct = listOf("JUPITER", "SATURN", "URANUS")
    val options = listOf(
        "MERCURY", "VENUS", "EARTH", "MARS",
        "JUPITER", "SATURN", "URANUS", "NEPTUNE"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = if (!showResult) "Planet Quiz" else "Answer",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
        )

        Spacer(Modifier.height(24.dp))

        if (!showResult) {
            Text(
                text = questions[currentQuestion],
                style = MaterialTheme.typography.titleLarge
            )
            Spacer(Modifier.height(16.dp))

            options.forEach { option ->
                Button(
                    onClick = {
                        selectedAnswer = option
                        showResult = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2CD2E7))
                ) {
                    Text(option)
                }
            }
        } else {
            val isCorrect = selectedAnswer == correct[currentQuestion]
            Text(
                text = questions[currentQuestion],
                style = MaterialTheme.typography.titleLarge
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = if (isCorrect) "Correct!" else "Wrong!",
                color = if (isCorrect) Color(0xFF2E7D32) else Color(0xFFC62828),
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(12.dp))
            if (isCorrect) {
                Text(text = explanations[currentQuestion])
            } else {
                Text(text = "Try again.")
            }

            Spacer(Modifier.height(24.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = { showResult = false }, // go back to options for same question
                    modifier = Modifier.weight(1f)
                ) { Text("Back") }

                if (currentQuestion < questions.lastIndex) {
                    Button(
                        onClick = {
                            currentQuestion++
                            selectedAnswer = null
                            showResult = false
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Next") }
                } else {
                    Button(
                        onClick = {
                            // restart quiz
                            currentQuestion = 0
                            selectedAnswer = null
                            showResult = false
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Restart") }
                }
            }
        }
    }
}